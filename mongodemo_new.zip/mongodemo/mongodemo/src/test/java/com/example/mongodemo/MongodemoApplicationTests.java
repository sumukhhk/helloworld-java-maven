package com.example.mongodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
